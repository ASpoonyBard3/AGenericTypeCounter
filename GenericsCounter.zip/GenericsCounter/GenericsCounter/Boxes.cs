﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericsCounter
{
    public class Apples : Items
    {
        string Name = "a box";
        string Colour = "Red";
    }
}
