﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericsCounter
{
    class Program
    {
        static void Main(string[] args)
        {
           
        }
    }

    public interface ICountable { }
    public class Counter<T>
        where T : ICountable
    {
        public int Count(IEnumerable<T> items)
        { 
            return 0; 
        }

        public int Count(T item) 
        {
            return 0;
        }
    }

    public class Counter 
    {
        public int Count<T>(IEnumerable<T> items)
            where T : ICountable 
        {
            return 0;
        }

        public int Count<T>(IEnumerable<T> items)
            where T : ICountable 
        {
            return 0;
        }

    }



     public class Items
	 {
         public string Name { get; set; }
         public int Weight {get; set;}

         public Items(string name, int weight) 
         {
             Name = name;
             Weight = weight;
         }

	 }

     public class Carts : Items 
     {
         string Name = "Bob's Carts";
         string Description = "a cart owned by Bob.";

     }

     public class Boxes : Items 
     { 
        string Name = "a box";

     }
}
