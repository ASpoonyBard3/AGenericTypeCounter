﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericsCounter
{
    class Program
    {
        static void Main(string[] args)
        {
           
        }
    }

    public interface ICountable { }
    public class Counter<T>
        where T : ICountable
    {
        public int Count(IEnumerable<T> items)
        { 
            return 0; 
        }

        public int Count(T item) 
        {
            return 0;
        }
    }

    public class Counter 
    {
        public int Count<T>(IEnumerable<T> items)
            where T : ICountable 
        {
            return 0;
        }

        public int Count<T>(IEnumerable<T> items)
            where T : ICountable 
        {
            return 0;
        }

    }

    
}
