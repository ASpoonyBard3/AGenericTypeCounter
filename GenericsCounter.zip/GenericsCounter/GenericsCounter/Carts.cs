﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericsCounter
{
    public class Carts : Items
    {
        string Name = "Bob's Carts";
        string Description = "a cart owned by Bob.";

    }
}
