﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericsCounter
{
    public class Box : Counter<iCountable>
    {
        //doesn't need any code
    }
}

